import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  ChevronDown,
  Clock,
  Flame,
  User,
  Link2,
  Target,
  Sparkles,
  TrendingUp,
  Pencil,
  Check,
  X,
  Circle,
  PlayCircle,
  AlertTriangle,
  CheckCircle2,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { ActionStatus } from "./SprintProgress";

export type BacklogItemStatus = ActionStatus;

export interface BacklogItemROI {
  timeSavings?: string;
  riskReduction?: string;
  cost?: string;
  payback?: string;
}

export interface EditableFields {
  title: string;
  effort: number;
  owner: string;
  successMetric: string;
}

export interface BacklogItemProps {
  title: string;
  effort: number;
  impact: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW";
  owner: string;
  successMetric: string;
  dependencies?: string[];
  aiContext: string;
  estimatedROI?: BacklogItemROI;
  status?: BacklogItemStatus;
  isCustomized?: boolean;
  successMetricAchieved?: string | null;
  retrospectiveNotes?: string | null;
  onStatusChange?: (status: BacklogItemStatus) => void;
  onEdit?: (fields: EditableFields) => void;
  onMarkComplete?: () => void;
}

const impactStyles: Record<string, string> = {
  CRITICAL: "bg-destructive/10 text-destructive border-destructive/20",
  HIGH: "bg-orange-500/10 text-orange-600 border-orange-500/20",
  MEDIUM: "bg-yellow-500/10 text-yellow-700 border-yellow-500/20",
  LOW: "bg-muted text-muted-foreground border-border",
};

const statusConfig: Record<ActionStatus, { label: string; icon: typeof Circle; className: string }> = {
  not_started: { label: "Not Started", icon: Circle, className: "text-muted-foreground" },
  in_progress: { label: "In Progress", icon: PlayCircle, className: "text-primary" },
  blocked: { label: "Blocked", icon: AlertTriangle, className: "text-destructive" },
  complete: { label: "Complete", icon: CheckCircle2, className: "text-green-600" },
};

export default function BacklogItem({
  title,
  effort,
  impact,
  owner,
  successMetric,
  dependencies = [],
  aiContext,
  estimatedROI,
  status = "not_started",
  isCustomized,
  successMetricAchieved,
  retrospectiveNotes,
  onStatusChange,
  onEdit,
  onMarkComplete,
}: BacklogItemProps) {
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<EditableFields>({ title, effort, owner, successMetric });

  const handleStatusSelect = (newStatus: ActionStatus) => {
    if (newStatus === "complete" && onMarkComplete) {
      onMarkComplete();
    } else {
      onStatusChange?.(newStatus);
    }
  };

  const startEdit = (e: React.MouseEvent) => {
    e.stopPropagation();
    setDraft({ title, effort, owner, successMetric });
    setEditing(true);
    if (!open) setOpen(true);
  };

  const cancelEdit = () => setEditing(false);
  const saveEdit = () => {
    onEdit?.(draft);
    setEditing(false);
  };

  const current = statusConfig[status];
  const StatusIcon = current.icon;

  return (
    <Collapsible open={open} onOpenChange={setOpen}>
      <Card className={cn("transition-all", status === "complete" && "opacity-60")}>
        <CardHeader className="p-0">
          <div className="flex items-center gap-3 px-4 py-3">
            {/* Status dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className={cn("shrink-0 focus:outline-none", current.className)} aria-label="Change status">
                  <StatusIcon className="h-5 w-5" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="w-40">
                {(Object.keys(statusConfig) as ActionStatus[]).map((s) => {
                  const cfg = statusConfig[s];
                  const Icon = cfg.icon;
                  return (
                    <DropdownMenuItem key={s} onClick={() => handleStatusSelect(s)} className={cn(s === status && "bg-accent")}>
                      <Icon className={cn("mr-2 h-4 w-4", cfg.className)} />
                      {cfg.label}
                    </DropdownMenuItem>
                  );
                })}
              </DropdownMenuContent>
            </DropdownMenu>

            <CollapsibleTrigger className="flex flex-1 items-center gap-3 text-left min-w-0">
              <ChevronDown
                className={cn(
                  "h-4 w-4 shrink-0 text-muted-foreground transition-transform",
                  open ? "rotate-0" : "-rotate-90"
                )}
              />
              {editing ? (
                <Input
                  value={draft.title}
                  onChange={(e) => setDraft((d) => ({ ...d, title: e.target.value }))}
                  onClick={(e) => e.stopPropagation()}
                  className="h-7 text-sm font-medium"
                />
              ) : (
                <span className={cn("text-sm font-medium truncate", status === "complete" && "line-through")}>
                  {title}
                </span>
              )}
            </CollapsibleTrigger>

            <div className="flex items-center gap-2 shrink-0">
              {isCustomized && (
                <Badge variant="outline" className="text-[10px] bg-accent/50 text-accent-foreground border-accent">
                  Edited
                </Badge>
              )}
              <span className="hidden sm:flex items-center gap-1 text-xs text-muted-foreground">
                <Clock className="h-3.5 w-3.5" />
                {effort}h
              </span>
              <Badge variant="outline" className={cn("text-[10px] font-semibold", impactStyles[impact])}>
                {impact}
              </Badge>
              {onEdit && !editing && (
                <Button variant="ghost" size="icon" className="h-7 w-7" onClick={startEdit}>
                  <Pencil className="h-3.5 w-3.5 text-muted-foreground" />
                </Button>
              )}
            </div>
          </div>
        </CardHeader>

        <CollapsibleContent>
          <CardContent className="border-t px-4 pt-4 pb-4 space-y-4">
            {editing ? (
              <div className="space-y-3">
                <div className="grid gap-3 sm:grid-cols-2">
                  <div>
                    <label className="text-xs text-muted-foreground">Effort (hours)</label>
                    <Input
                      type="number"
                      min={1}
                      value={draft.effort}
                      onChange={(e) => setDraft((d) => ({ ...d, effort: Math.max(1, Number(e.target.value)) }))}
                      className="mt-1 h-8 text-sm"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-muted-foreground">Owner</label>
                    <Input
                      value={draft.owner}
                      onChange={(e) => setDraft((d) => ({ ...d, owner: e.target.value }))}
                      className="mt-1 h-8 text-sm"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs text-muted-foreground">Success Metric</label>
                  <Input
                    value={draft.successMetric}
                    onChange={(e) => setDraft((d) => ({ ...d, successMetric: e.target.value }))}
                    className="mt-1 h-8 text-sm"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Button size="sm" onClick={saveEdit}>
                    <Check className="mr-1.5 h-3.5 w-3.5" /> Save Changes
                  </Button>
                  <Button size="sm" variant="ghost" onClick={cancelEdit}>
                    <X className="mr-1.5 h-3.5 w-3.5" /> Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <>
                <div className="grid gap-3 sm:grid-cols-2">
                  <Detail icon={Clock} label="Effort" value={`${effort} hours`} />
                  <Detail icon={Flame} label="Impact" value={impact} />
                  <Detail icon={User} label="Owner" value={owner} />
                  <Detail icon={Target} label="Success Metric" value={successMetric} />
                </div>

                {dependencies.length > 0 && (
                  <div className="flex items-start gap-2 text-sm">
                    <Link2 className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                    <div>
                      <span className="text-xs font-medium text-muted-foreground">Dependencies</span>
                      <div className="mt-1 flex flex-wrap gap-1.5">
                        {dependencies.map((dep) => (
                          <Badge key={dep} variant="secondary" className="text-[10px]">{dep}</Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {aiContext && (
                  <div className="rounded-lg border border-primary/20 bg-primary/5 p-3">
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-primary mb-1">
                      <Sparkles className="h-3.5 w-3.5" /> Why this matters
                    </div>
                    <p className="text-sm text-foreground/80 leading-relaxed">{aiContext}</p>
                  </div>
                )}

                {estimatedROI && Object.values(estimatedROI).some(Boolean) && (
                  <div className="rounded-lg border bg-muted/40 p-3">
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-muted-foreground mb-2">
                      <TrendingUp className="h-3.5 w-3.5" /> ROI Breakdown
                    </div>
                    <div className="grid gap-2 sm:grid-cols-2 text-sm">
                      {estimatedROI.timeSavings && <ROIRow label="Time Savings" value={estimatedROI.timeSavings} />}
                      {estimatedROI.riskReduction && <ROIRow label="Risk Reduction" value={estimatedROI.riskReduction} />}
                      {estimatedROI.cost && <ROIRow label="Cost" value={estimatedROI.cost} />}
                      {estimatedROI.payback && <ROIRow label="Payback" value={estimatedROI.payback} />}
                    </div>
                  </div>
                )}

                {/* Completion badge & retrospective */}
                {status === "complete" && successMetricAchieved && (
                  <div className={cn(
                    "rounded-lg border p-3 text-sm",
                    successMetricAchieved === "yes" ? "border-green-500/20 bg-green-500/5" :
                    successMetricAchieved === "partially" ? "border-yellow-500/20 bg-yellow-500/5" :
                    "border-destructive/20 bg-destructive/5"
                  )}>
                    <div className="flex items-center gap-1.5 text-xs font-semibold mb-1">
                      {successMetricAchieved === "yes" ? <CheckCircle2 className="h-3.5 w-3.5 text-green-600" /> :
                       successMetricAchieved === "partially" ? <AlertTriangle className="h-3.5 w-3.5 text-yellow-600" /> :
                       <X className="h-3.5 w-3.5 text-destructive" />}
                      Success Metric: {successMetricAchieved === "yes" ? "Achieved" : successMetricAchieved === "partially" ? "Partially Achieved" : "Not Achieved"}
                    </div>
                    {retrospectiveNotes && (
                      <p className="text-muted-foreground mt-1">{retrospectiveNotes}</p>
                    )}
                  </div>
                )}

                {status !== "not_started" && (
                  <Badge
                    variant="outline"
                    className={cn("text-[10px]", current.className, "border-current/20")}
                  >
                    {current.label}
                  </Badge>
                )}
              </>
            )}
          </CardContent>
        </CollapsibleContent>
      </Card>
    </Collapsible>
  );
}

function Detail({ icon: Icon, label, value }: { icon: typeof Clock; label: string; value: string }) {
  return (
    <div className="flex items-start gap-2 text-sm">
      <Icon className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
      <div>
        <span className="text-xs text-muted-foreground">{label}</span>
        <p className="font-medium">{value}</p>
      </div>
    </div>
  );
}

function ROIRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value}</span>
    </div>
  );
}
